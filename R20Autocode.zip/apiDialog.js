(function() {
  //,"https://app.roll20.net/campaigns/scripts/","https://app.roll20staging.net/campaigns/scripts/"
})();